### 教程

1. post.exe是只跑接口, `update.php`,`sql.php`,`delete.php`
2. get.exe 是只跑域名的首页标题
3. domain.txt 是放数据, 要带http协议,默认全部域名加www前缀
4. 如果出现域名是301但是你没放www也不要来问我,我也不会说
5. `config.json` TOKEN参数为站点根目录的token值
6. 跑接口正确会显示`Response: {'status': 'success', 'message': 'TURE'}`,错误会输出其他日志
