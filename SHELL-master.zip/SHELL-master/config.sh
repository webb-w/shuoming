


# api start 禁止修改
redirect="https://api.myyjjpp.com/api/301"
biying="https://api.myyjjpp.com/api/biying"
baidu="https://api.myyjjpp.com/api/baidu"
delete="https://api.myyjjpp.com/api/delete"
nginx="https://api.myyjjpp.com/api/nginx"
renewal="https://api.myyjjpp.com/api/renewal"
sql="https://api.myyjjpp.com/api/sql"
ssl="https://api.myyjjpp.com/api/ssl"
# api end 禁止修改



# root and web start 自定义
root_mysql_password="1a613f07b597a2ab"
domain_mysql_password="1a613f07b597a2ab"
update_file_name="update"
sql_file_name="sql"
# root and web end 自定义