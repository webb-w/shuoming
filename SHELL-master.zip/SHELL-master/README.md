<p align="center"><img src="https://www.qqkw.com/d/file/p/2018/07-04/d488059ba32df251629b1b6d52686cf4.jpg" width="400"></p>

<p align="center">
<a href="https://opensource.org/licenses/MIT"><img src="https://img.shields.io/badge/license-MIT-blue" alt="license MIT"></a>
<a href="https://github.com/program-myyjjpp/TIM/"><img src="https://img.shields.io/badge/version-2.1-red" alt="version 2.0.4"></a>
<a href="https://www.php.net/releases/8_0.php"><img src="https://img.shields.io/badge/PHP-8.0-lightgrey" alt="php80"></a>
<a href="https://t.me/myyjjpp"><img src="https://img.shields.io/badge/Telegram-myyjjpp-0088cc" alt="Telegram: myyjjpp"></a>
</p>




## 安装篇
- [宝塔安装教程](https://github.com/program-myyjjpp/TIM/wiki)
