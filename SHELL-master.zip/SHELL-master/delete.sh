# 执行delete.txt里面的所有的命令
# 没有明显的错误爆红默认为true



source /www/script/config.sh
eval "$(curl -s "$delete")"